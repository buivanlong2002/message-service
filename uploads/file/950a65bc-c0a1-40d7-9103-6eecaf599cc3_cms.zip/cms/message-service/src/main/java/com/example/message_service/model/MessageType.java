package com.example.message_service.model;

public enum MessageType {
    TEXT,
    IMAGE,
    FILE,
    VIDEO
}
