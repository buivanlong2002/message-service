package com.example.message_service.service;

import com.example.message_service.dto.ApiResponse;
import com.example.message_service.dto.request.UpdateConversationRequest;
import com.example.message_service.dto.response.ConversationResponse;
import com.example.message_service.dto.response.LastMessageInfo;
import com.example.message_service.model.*;
import com.example.message_service.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ConversationService {

    @Autowired
    private ConversationRepository conversationRepository;

    @Autowired
    private ConversationMemberRepository conversationMemberRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ConversationMemberService conversationMemberService;

    @Autowired
    private MessageRepository messageRepository;

    public Conversation createGroupConversation(String name, String createdBy) {
        Conversation conversation = new Conversation();
        conversation.setName(name);
        conversation.setGroup(true);
        conversation.setCreatedBy(createdBy);
        conversation.setCreatedAt(LocalDateTime.now());

        Conversation saved = conversationRepository.save(conversation);
        conversationMemberService.addCreatorToConversation(saved);
        return saved;
    }

    public Conversation getOrCreateOneToOneConversation(String senderId, String receiverId) {
        Optional<Conversation> existing = findOneToOneConversation(senderId, receiverId);
        if (existing.isPresent()) return existing.get();

        Conversation conversation = new Conversation();
        conversation.setGroup(false);
        conversation.setName(null);
        conversation.setCreatedBy(senderId);
        conversation.setCreatedAt(LocalDateTime.now());

        Conversation saved = conversationRepository.save(conversation);
        conversationMemberService.addMemberToConversation(saved, senderId, "member");
        conversationMemberService.addMemberToConversation(saved, receiverId, "member");

        return saved;
    }

    public Conversation createDynamicGroupFromMessage(String senderId, String receiverId) {
        Optional<User> senderOpt = userRepository.findById(senderId);
        if (senderOpt.isEmpty()) throw new RuntimeException("Sender not found");

        String groupName = senderOpt.get().getDisplayName();
        Conversation group = new Conversation();
        group.setGroup(true);
        group.setName(groupName);
        group.setCreatedBy(senderId);
        group.setCreatedAt(LocalDateTime.now());

        Conversation saved = conversationRepository.save(group);
        conversationMemberService.addMemberToConversation(saved, senderId, "member");
        conversationMemberService.addMemberToConversation(saved, receiverId, "member");

        return saved;
    }

    public ApiResponse<ConversationResponse> updateConversation(String conversationId, UpdateConversationRequest request) {
        Optional<Conversation> optional = conversationRepository.findById(conversationId);
        if (optional.isEmpty()) {
            return ApiResponse.error("04", "Không tìm thấy cuộc trò chuyện với ID: " + conversationId);
        }

        Conversation conversation = optional.get();
        conversation.setName(request.getName());
        conversation.setGroup(request.isGroup());
        conversationRepository.save(conversation);

        ConversationResponse dto = toConversationResponse(conversation, null, null);
        return ApiResponse.success("00", "Cập nhật cuộc trò chuyện thành công", dto);
    }

    public void archiveConversation(String conversationId) {
        conversationRepository.findById(conversationId).ifPresent(c -> {
            c.setArchived(true);
            conversationRepository.save(c);
        });
    }

    public ApiResponse<List<ConversationResponse>> getConversationsByUser(String userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) {
            return ApiResponse.error("03", "Không tìm thấy người dùng: " + userId);
        }

        List<ConversationMember> members = conversationMemberRepository.findByUserId(userId);
        List<Conversation> conversations = members.stream()
                .map(ConversationMember::getConversation)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());

        // Lấy last message cho mỗi conversation
        Map<String, Message> lastMessages = new HashMap<>();
        for (Conversation conv : conversations) {
            Message lastMsg = messageRepository.findTopByConversationIdOrderByCreatedAtDesc(conv.getId());
            if (lastMsg != null) {
                lastMessages.put(conv.getId(), lastMsg);
            }
        }

        List<ConversationResponse> responses = conversations.stream()
                .map(conv -> toConversationResponse(conv, userId, lastMessages.get(conv.getId())))
                .sorted((a, b) -> {
                    LocalDateTime timeA = a.getLastMessage() != null ? a.getLastMessage().getCreatedAt() : a.getCreatedAt();
                    LocalDateTime timeB = b.getLastMessage() != null ? b.getLastMessage().getCreatedAt() : b.getCreatedAt();
                    return timeB.compareTo(timeA); // Mới nhất lên đầu
                })
                .collect(Collectors.toList());

        return ApiResponse.success("00", "Lấy danh sách cuộc trò chuyện thành công", responses);
    }

    private Optional<Conversation> findOneToOneConversation(String userId1, String userId2) {
        return conversationMemberRepository.findByUserId(userId1).stream()
                .map(ConversationMember::getConversation)
                .filter(conv -> !conv.isGroup())
                .filter(conv -> {
                    List<ConversationMember> members = conversationMemberRepository.findByConversationId(conv.getId());
                    return members.size() == 2 &&
                            members.stream().anyMatch(m -> m.getUser().getId().equals(userId2));
                })
                .findFirst();
    }

    public ApiResponse<List<ConversationResponse>> getConversationsByUserPaged(String userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());

        Page<Conversation> conversationPage = conversationRepository.findConversationById(userId, pageable);

        List<ConversationResponse> responseList = conversationPage.getContent().stream().map(conversation -> {
            // Tìm tin nhắn cuối
            Message lastMessage = messageRepository.findTopByConversationIdOrderByCreatedAtDesc(conversation.getId());

            LastMessageInfo lastMessageInfo = null;
            if (lastMessage != null) {
                lastMessageInfo = new LastMessageInfo(
                        lastMessage.getContent(),
                        lastMessage.getSender().getDisplayName(),
                        getTimeAgo(lastMessage.getCreatedAt()),
                        lastMessage.getCreatedAt()
                );
            }

            return new ConversationResponse(
                    conversation.getId(),
                    conversation.getName(),
                    conversation.isGroup(),
                    conversation.getAvatarUrl(),
                    conversation.getCreatedAt(),
                    lastMessageInfo
            );
        }).collect(Collectors.toList());

        return ApiResponse.success("00", "Lấy danh sách nhóm thành công", responseList);
    }


    private ConversationResponse toConversationResponse(Conversation conversation, String requesterId, Message lastMessage) {
        String name;
        String avatarUrl = null;

        // Lấy danh sách thành viên của cuộc trò chuyện
        List<ConversationMember> members = conversationMemberRepository.findByConversationId(conversation.getId());

        if (conversation.isGroup()) {
            // Trường hợp nhóm: lấy tên và avatar của nhóm
            name = conversation.getName();
            avatarUrl = conversation.getAvatarUrl(); // Có thể null nếu chưa upload
        } else {
            // Trường hợp 1-1: tìm người còn lại (khác với requester)
            Optional<User> partnerOpt = members.stream()
                    .map(ConversationMember::getUser)
                    .filter(user -> !user.getId().equals(requesterId))
                    .findFirst();

            User partner = partnerOpt.orElse(null);

            // Nếu tìm được người còn lại, lấy tên + avatar của họ làm tên và avatar nhóm
            name = partner != null ? partner.getDisplayName() : "Cuộc trò chuyện";
            avatarUrl = partner != null ? partner.getAvatarUrl() : null;
        }

        // Chuẩn bị thông tin tin nhắn cuối
        LastMessageInfo lastMessageInfo = null;
        if (lastMessage != null) {
            lastMessageInfo = new LastMessageInfo(
                    lastMessage.getContent(),
                    lastMessage.getSender().getDisplayName(),
                    getTimeAgo(lastMessage.getCreatedAt()),
                    lastMessage.getCreatedAt()
            );
        }

        // Trả về DTO hoàn chỉnh
        return new ConversationResponse(
                conversation.getId(),
                name,
                conversation.isGroup(),
                avatarUrl,
                conversation.getCreatedAt(),
                lastMessageInfo
        );
    }


    public ApiResponse<String> updateGroupAvatar(String conversationId, MultipartFile file) {
        Optional<Conversation> optional = conversationRepository.findById(conversationId);
        if (optional.isEmpty()) {
            return ApiResponse.error("04", "Không tìm thấy cuộc trò chuyện");
        }

        Conversation conversation = optional.get();
        if (!conversation.isGroup()) {
            return ApiResponse.error("05", "Chỉ nhóm mới được cập nhật ảnh đại diện");
        }

        try {
            String originalFilename = Path.of(file.getOriginalFilename()).getFileName().toString();
            String fileName = UUID.randomUUID() + "_" + originalFilename;
            String uploadDir = "uploads/conversations/";

            // Tạo thư mục nếu chưa có
            Path dir = Paths.get(uploadDir);
            Files.createDirectories(dir);

            Path filePath = dir.resolve(fileName);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            String avatarUrl = "/uploads/conversations/" + fileName;
            conversation.setAvatarUrl(avatarUrl);
            conversationRepository.save(conversation);

            return ApiResponse.success("00", "Cập nhật ảnh đại diện nhóm thành công", avatarUrl);

        } catch (IOException e) {
            return ApiResponse.error("06", "Lỗi khi upload ảnh đại diện nhóm");
        }
    }



    private String getTimeAgo(LocalDateTime createdAt) {
        Duration duration = Duration.between(createdAt, LocalDateTime.now());
        if (duration.toMinutes() < 1) return "Vừa xong";
        if (duration.toHours() < 1) return duration.toMinutes() + " phút trước";
        if (duration.toDays() < 1) return duration.toHours() + " giờ trước";
        return duration.toDays() + " ngày trước";
    }
}
