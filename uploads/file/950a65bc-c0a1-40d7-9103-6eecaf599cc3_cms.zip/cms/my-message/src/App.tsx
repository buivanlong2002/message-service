// src/App.tsx
import { useEffect } from 'react';
import { connectWebSocket } from './websocket'; 

function App() {
  useEffect(() => {
    connectWebSocket();
  }, []);

  return (
    <div>
      <h1>🔌 Kiểm tra WebSocket</h1>
      <p>Kiểm tra console để xem kết nối và tin nhắn.</p>
    </div>
  );
}

export default App;
