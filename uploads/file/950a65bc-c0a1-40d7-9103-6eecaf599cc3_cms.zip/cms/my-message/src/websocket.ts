import { Client } from '@stomp/stompjs';
import type { IMessage } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

// ⚙️ Thông tin người dùng
const userId = 'a1fda5ee-637d-41ad-8edb-88f21466154b';
const token = 'Bearer eyJhbGciOiJSUzI1NiJ9.eyJuYW1lIjoiaG9hbmdAZXhhbXBsZS5jb20iLCJpZCI6ImExZmRhNWVlLTYzN2QtNDFhZC04ZWRiLTg4ZjIxNDY2MTU0YiIsImVtYWlsIjoiaG9hbmdAZXhhbXBsZS5jb20iLCJzdWIiOiJob2FuZ0BleGFtcGxlLmNvbSIsImlhdCI6MTc1MDkyMDk1NywiZXhwIjoxNzU0NTIwOTU3fQ.JI6C7LI52HCWTfKGP1015E71Daq5F6IZLLpvn1Jec1LOCN7r-VxYPeqw_2rVngZJqCX4DIJsHRpmGeTYw9t6LkrIL5MvC4QO_lpB6zujiYW1JXPNc66qOzoAmI-I0R8pjZm_vWFFb2yUN8h9EUQ96YFA70EwejAsRaijfH23qeSVdKeVeja8kFcnwq92ZBoR_lTK4dSztUW-i0yjRSw6epVG5rKgq5eT8Vl5GKaAGAlUhxOpntPz58fzvl3fxFFJZDKmj7q6UnlZ5qxWGuZs8bnpgk78AGFn8oh_TbI7CHEHgELTo8AESOgtKj210fpysX38NRrPd8W57Hl9YM9oWQ'; // JWT của bạn

// 🧠 Tạo STOMP client
const stompClient = new Client({
  // Không truyền token trong URL!
  webSocketFactory: () => new SockJS('http://localhost:8885/ws'),

  // ✅ Truyền token qua header STOMP
  connectHeaders: {
    Authorization: token,
  },

  // Debug logs
  debug: (str) => console.log('[STOMP]', str),
  reconnectDelay: 5000,

  // Khi kết nối thành công
  onConnect: () => {
    console.log('🟢 WebSocket đã kết nối');

    // 🎯 Subcribe để nhận tin nhắn
    stompClient.subscribe(`/user/${userId}/queue/conversations`, (message: IMessage) => {
      try {
        const data = JSON.parse(message.body);
        console.log('📥 Nhận hội thoại:', data);
      } catch (err) {
        console.error('❌ Lỗi phân tích dữ liệu:', err);
      }
    });

    // 🚀 Gửi yêu cầu lấy danh sách hội thoại
    stompClient.publish({
      destination: `/app/user/${userId}/conversations`,
      body: '',
    });
  },

  // Khi có lỗi STOMP
  onStompError: (frame) => {
    console.error('❌ STOMP lỗi:', frame.headers['message'], frame.body);
  },

  // Khi lỗi WebSocket (ví dụ bị 403)
  onWebSocketError: (event) => {
    console.error('🚨 Lỗi WebSocket:', event);
  },
});

// 📌 Hàm kích hoạt kết nối
export function connectWebSocket() {
  stompClient.activate();
}
